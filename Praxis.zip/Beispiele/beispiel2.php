<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Google Dorks</title>
	</head>

	<body>
		<a href="http://sqlinjectionwwi.bplaced.net/">Zurück</a><br><br>
		<h1>Beispiel 2</h1>
		<p>Google Dorks nutzen um Ziele zu finden:<br><br>Beispiel:</p><code>inurl:"product.php?id="</code><br><br><p>In die Google Suchleiste eingeben.</p>
	</body>

</html> 
